/*
 * dc1.h
 *
 *  Created on: 28 may. 2021
 *      Author: dante
 */

#ifndef DC1_H_
#define DC1_H_
extern void pinMode(unsigned char Port_1, unsigned char Pin_1, unsigned char inout_1);
extern int digitalRead(unsigned char Port_3, unsigned char pin_3);
extern void digitalWrite(unsigned char Port_2, unsigned char pin_2, unsigned char inout_2);

#endif /* DC1_H_ */
