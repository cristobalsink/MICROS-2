/*
 * jp.c
 *
 *  Created on: 28 may. 2021
 *      Author: dante
 */
#include "dc1.h"
#include "MKL25Z4.h"
void pinMode(unsigned char Port_1, unsigned char Pin_1, unsigned char inout_1){
	//Activacion de reloj




		if(Port_1 == 'A')
		{
			SIM->SCGC5 = 0x200;

			PORTA->PCR[Pin_1] = 0x100;
			if(inout_1 == 1)
			{
				GPIOA->PDDR |= 1<<Pin_1;//1<<10

			}else if(inout_1 == 0)
			{
				GPIOA->PDDR &= ~(1<<Pin_1);
			}


		}else if(Port_1 == 'B')
		{
			SIM->SCGC5 = 0x400;
			PORTB->PCR[Pin_1] = 0x100;
			if(inout_1 == 1)
			{
				GPIOB->PDDR |= 1<<Pin_1;

			}else if(inout_1 == 0)
			{
				GPIOB->PDDR &= ~(1<<Pin_1);
			}

		}else if(Port_1 == 'C')
		{
			SIM->SCGC5 = 0x800;
			PORTC->PCR[Pin_1] = 0x100;
			if(inout_1 == 1)
			{
				GPIOC->PDDR |= 1<<Pin_1;

			}else if(inout_1 == 0)
			{
				GPIOC->PDDR &= ~(1<<Pin_1);
			}

		}else if(Port_1 == 'D')
		{
			SIM->SCGC5 = 0x1000;
			PORTD->PCR[Pin_1] = 0x100;
			if(inout_1 == 1)
			{
				GPIOD->PDDR |= 1<<Pin_1;

			}else if(inout_1 == 0)
			{
				GPIOD->PDDR &= ~(1<<Pin_1);
			}

		}else if(Port_1 == 'E')
		{
			SIM->SCGC5 = 0x2000;
			PORTE->PCR[Pin_1] = 0x100;
			if(inout_1 == 1)
			{
				GPIOE->PDDR |= 1<<Pin_1;

			}else if(inout_1 == 0)
			{
				GPIOE->PDDR &= ~(1<<Pin_1);
			}
		}

		return 0;

}

void digitalWrite(unsigned char Port_2, unsigned char pin_2, unsigned char inout_2){

	if(Port_2 == 'A')
		{
			if(inout_2 == 1)
			{
				GPIOA->PDOR |= 1<<pin_2;
			}else if(inout_2 == 0)
			{
				GPIOA->PDOR &= ~(1<<pin_2);
			}
		}else if(Port_2 == 'B')
		{
			if(inout_2 == 1)
			{
				GPIOB->PDOR |= 1<<pin_2;
			}else if(inout_2 == 0)
			{
				GPIOB->PDOR &= ~(1<<pin_2);
			}
		}else if(Port_2 == 'C')
		{
			if(inout_2 == 1)
			{
				GPIOC->PDOR |= 1<<pin_2;
			}else if(inout_2 == 0)
			{
				GPIOC->PDOR &= ~(1<<pin_2);
			}
		}else if(Port_2 == 'D')
		{
			if(inout_2 == 1)
			{
				GPIOD->PDOR |= 1<<pin_2;
			}else if(inout_2 == 0)
			{
				GPIOD->PDOR &= ~(1<<pin_2);
			}
		}else if(Port_2 == 'E')
		{
			if(inout_2 == 1)
			{
				GPIOE->PDOR |= 1<<pin_2;
			}else if(inout_2 == 0)
			{
				GPIOE->PDOR &= ~(1<<pin_2);
			}
		}
}

int digitalRead(unsigned char Port_3, unsigned char pin_3){
	int X = 0;
		if(Port_3 == 'A')
		{
			X = (GPIOA->PDIR & (1<<pin_3));

		}else if(Port_3 == 'B')
		{
			X = (GPIOB->PDIR & (1<<pin_3));

		}else if(Port_3 == 'C')
		{
			X = (GPIOC->PDIR & (1<<pin_3));

		}else if(Port_3 == 'D')
		{
			X = (GPIOD->PDIR & (1<<pin_3));

		}else if(Port_3 == 'E')
		{
			X = (GPIOE->PDIR & (1<<pin_3));

		}

		return X;
	}



